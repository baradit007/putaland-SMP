To add custom recipes, create .json files in this directory that contain a single recipe.
To understand the basis of how recipes are read/written, use following command:
/tc server export recipe <RECIPE_ID>
...Where <RECIPE_ID> is a unique id of a recipe in-game. Use tab completion to get more info on that.